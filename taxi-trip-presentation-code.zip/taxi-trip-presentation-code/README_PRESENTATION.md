# Presentation Code Pack

This folder contains selected, unmodified source files from the working
**Uber / Taxi Trip Data Analysis Using Apache Spark** project. The frontend
dashboard and Flask/PySpark backend are separate; the API contract and generated
client files are included to show how they connect.

## Suggested presentation order

1. **Architecture and endpoints** — `api/openapi.yaml`  
   Show the REST endpoints and the shared query filters (`dataset`,
   `startDate`, `endDate`, and `pickupZone`).
2. **Frontend entry point** — `frontend/src/main.tsx`, then
   `frontend/src/App.tsx`  
   Explain how React starts, wraps the app in data providers, and routes to the
   dashboard.
3. **Frontend dashboard and live API data** — `frontend/src/pages/dashboard.tsx`  
   Useful sections to open:
   - Around lines 131–175: dataset selection and API-backed queries.
   - Around lines 186–227: Chart.js data is mapped from API responses.
   - Around lines 294–329: date, zone/city, and dataset filters.
   - Around lines 350–423: KPI cards, charts, and recent-trip records.
   - Around lines 229–231: filtered CSV download.
4. **Backend and Spark processing** — `backend/app.py`  
   Useful sections to open:
   - Around lines 33–113: input schemas and dataset definitions.
   - Around lines 130–208: PySpark CSV loading, normalization, cleaning,
     deduplication, caching, and record counts.
   - Around lines 221–237: date and pickup-zone filtering.
   - Around lines 265–300: Spark-backed health check and summary API.
   - Around lines 328–391: hourly, pickup-area, and daily-revenue analytics.
   - Around lines 438–483: filtered CSV export and error responses.
5. **Dependencies and request connection** — `backend/requirements.txt`,
   `frontend/package.json`, `frontend/vite.config.ts`, and
   `frontend/lib/api-client-react/`  
   The generated React API client is based on the OpenAPI contract. In
   standalone Windows development, Vite proxies `/api` requests to Flask.

## What to say about the data

- The uploaded CSV has 50,000 source rows. With the implemented cleaning rules,
  42,538 completed valid rides are included in analytics.
- A separate hand-authored dataset is synthetic and intended for teaching.
- The uploaded file's real-world authenticity and redistribution license have
  not been independently verified.
- PySpark runs in local mode (`local[*]`); this project does not claim to use a
  Spark cluster or Cassandra.

## Running and testing

For full Windows installation instructions and API test commands, use the
project's main `README.md` in the complete source ZIP. The backend dependency
list is included here as `backend/requirements.txt`.

The files in this pack are for reading and presenting. Use the complete project
source ZIP to run the entire application, because this smaller pack does not
include the datasets or every UI component dependency.
