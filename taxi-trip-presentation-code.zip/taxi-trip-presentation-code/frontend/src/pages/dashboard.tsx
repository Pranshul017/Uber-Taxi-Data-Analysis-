import { useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Tooltip,
  Filler,
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';
import {
  Activity,
  ArrowDownToLine,
  ArrowUpRight,
  BarChart3,
  CalendarDays,
  CarFront,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Database,
  MapPin,
  RotateCcw,
  Wallet,
} from 'lucide-react';
import {
  getExportTripsCsvQueryKey,
  getExportTripsCsvUrl,
  getGetDailyRevenueQueryKey,
  getGetTripsByHourQueryKey,
  getGetTripsByPickupZoneQueryKey,
  getGetTripsQueryKey,
  getGetTripsSummaryQueryKey,
  getGetTripFiltersQueryKey,
  useExportTripsCsv,
  useGetDailyRevenue,
  useGetTrips,
  useGetTripsByHour,
  useGetTripsByPickupZone,
  useGetTripsSummary,
  useGetTripFilters,
  useHealthCheck,
} from '@workspace/api-client-react';
import type {
  DailyRevenue,
  HourlyTripCount,
  Trip,
  TripSummary,
  TripFilters,
  TripsPage,
  ZoneTripCount,
} from '@workspace/api-client-react';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Tooltip, Filler);

type FilterState = { startDate: string; endDate: string; pickupZone: string };

const currency = (value: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(value);
const number = (value: number) => new Intl.NumberFormat('en-US').format(value);
const hourLabel = (hour: number) => `${String(hour).padStart(2, '0')}:00`;
const dayLabel = (value: string) =>
  new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' }).format(new Date(`${value}T00:00:00Z`));
const timeLabel = (value: string) =>
  new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(value));
const errorMessage = (error: unknown) => error instanceof Error ? error.message : 'The dataset could not be loaded.';

const chartTooltip = {
  backgroundColor: '#173c39',
  titleFont: { family: 'DM Mono', size: 11 },
  bodyFont: { family: 'DM Sans', size: 12 },
  padding: 11,
  cornerRadius: 7,
  displayColors: false,
};

function SkeletonBlock({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} aria-hidden="true" />;
}

function ChartState({ loading, error, empty, onRetry, children }: {
  loading: boolean;
  error: unknown;
  empty: boolean;
  onRetry: () => void;
  children: ReactNode;
}) {
  if (loading) return <div className="chart-wrap flex flex-col gap-3 pt-4"><SkeletonBlock className="h-4 w-1/3" /><SkeletonBlock className="h-full w-full" /></div>;
  if (error) return <div className="flex h-[255px] flex-col items-center justify-center gap-2 text-center">
    <p className="text-sm font-semibold">Chart unavailable</p>
    <p className="max-w-xs text-xs text-muted-foreground">{errorMessage(error)}</p>
    <button className="action-button outline mt-1" onClick={onRetry} data-testid="button-retry-chart"><RotateCcw size={13} /> Try again</button>
  </div>;
  if (empty) return <div className="flex h-[255px] flex-col items-center justify-center gap-2 text-center text-muted-foreground">
    <BarChart3 size={22} strokeWidth={1.5} />
    <p className="text-sm font-medium text-foreground">No trips in this slice</p>
    <p className="text-xs">Try a broader date range or another pickup zone.</p>
  </div>;
  return <div className="chart-wrap">{children}</div>;
}

function Metric({ label, value, detail, icon: Icon, loading }: {
  label: string;
  value: string;
  detail: string;
  icon: typeof CarFront;
  loading: boolean;
}) {
  return <article className="panel p-4 sm:p-5">
    <div className="flex items-start justify-between gap-3">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[.11em] text-muted-foreground">{label}</p>
        {loading ? <SkeletonBlock className="mt-3 h-8 w-28" /> :
          <p className="font-display mt-2 text-[27px] font-bold leading-none tracking-[-.04em]" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</p>}
      </div>
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-secondary text-primary"><Icon size={17} strokeWidth={1.8} /></span>
    </div>
    <p className="mt-4 text-[11px] text-muted-foreground">{detail}</p>
  </article>;
}

function LoadingTable() {
  return <div className="space-y-3 px-4 py-5">{Array.from({ length: 5 }, (_, index) =>
    <SkeletonBlock className="h-8 w-full" key={index} />)}</div>;
}

export default function Dashboard() {
  const [selectedDataset, setSelectedDataset] = useState<TripFilters['datasetId']>('uber_50k');
  const filterParams = useMemo(() => ({ dataset: selectedDataset }), [selectedDataset]);
  const filterQuery = useGetTripFilters(filterParams, {
    query: { queryKey: getGetTripFiltersQueryKey(filterParams) },
  });
  const filters = filterQuery.data as TripFilters | undefined;
  const [selected, setSelected] = useState<FilterState>({ startDate: '', endDate: '', pickupZone: '' });
  const [readyDataset, setReadyDataset] = useState('');

  useEffect(() => {
    if (filters && filters.datasetId === selectedDataset && readyDataset !== selectedDataset) {
      setSelected({
        startDate: filters.minDate ?? '',
        endDate: filters.maxDate ?? '',
        pickupZone: '',
      });
      setReadyDataset(selectedDataset);
    }
  }, [filters, readyDataset, selectedDataset]);
  const initialized = readyDataset === selectedDataset && filters?.datasetId === selectedDataset;

  const params = useMemo(() => ({
    dataset: selectedDataset,
    ...(selected.startDate ? { startDate: selected.startDate } : {}),
    ...(selected.endDate ? { endDate: selected.endDate } : {}),
    ...(selected.pickupZone ? { pickupZone: selected.pickupZone } : {}),
  }), [selected, selectedDataset]);
  const summaryQuery = useGetTripsSummary(params, { query: { enabled: initialized, queryKey: getGetTripsSummaryQueryKey(params) } });
  const hourlyQuery = useGetTripsByHour(params, { query: { enabled: initialized, queryKey: getGetTripsByHourQueryKey(params) } });
  const zoneQuery = useGetTripsByPickupZone(params, { query: { enabled: initialized, queryKey: getGetTripsByPickupZoneQueryKey(params) } });
  const revenueQuery = useGetDailyRevenue(params, { query: { enabled: initialized, queryKey: getGetDailyRevenueQueryKey(params) } });
  const tripsParams = useMemo(() => ({ ...params, limit: 10, offset: 0 }), [params]);
  const tripsQuery = useGetTrips(tripsParams, { query: { enabled: initialized, queryKey: getGetTripsQueryKey(tripsParams) } });
  const healthQuery = useHealthCheck();
  useExportTripsCsv(params, {
    query: { enabled: false, queryKey: getExportTripsCsvQueryKey(params) },
  });

  const summary = summaryQuery.data as TripSummary | undefined;
  const hourly = hourlyQuery.data as HourlyTripCount[] | undefined;
  const zones = zoneQuery.data as ZoneTripCount[] | undefined;
  const daily = revenueQuery.data as DailyRevenue[] | undefined;
  const trips = tripsQuery.data as TripsPage | undefined;

  const chartOptions = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: chartTooltip },
    scales: {
      x: { grid: { display: false }, border: { display: false }, ticks: { color: '#7d8983', font: { family: 'DM Mono', size: 10 } } },
      y: { beginAtZero: true, grid: { color: 'rgba(91,112,102,.11)' }, border: { display: false }, ticks: { color: '#7d8983', precision: 0, font: { family: 'DM Mono', size: 10 } } },
    },
  }), []);

  const dailyChartData = useMemo(() => ({
    labels: daily?.map(item => dayLabel(item.date)) ?? [],
    datasets: [{
      data: daily?.map(item => item.revenue) ?? [],
      borderColor: '#275f58',
      backgroundColor: (context: { chart: { ctx: CanvasRenderingContext2D } }) => {
        const gradient = context.chart.ctx.createLinearGradient(0, 0, 0, 260);
        gradient.addColorStop(0, 'rgba(39,95,88,.21)');
        gradient.addColorStop(1, 'rgba(39,95,88,0)');
        return gradient;
      },
      fill: true,
      tension: .35,
      pointRadius: daily && daily.length > 24 ? 0 : 2.5,
      pointHoverRadius: 5,
      pointBackgroundColor: '#275f58',
      borderWidth: 2,
    }],
  }), [daily]);

  const hourlyChartData = useMemo(() => ({
    labels: hourly?.map(item => hourLabel(item.hour)) ?? [],
    datasets: [{
      data: hourly?.map(item => item.trips) ?? [],
      backgroundColor: hourly?.map(item => item.hour >= 7 && item.hour <= 10 || item.hour >= 16 && item.hour <= 19 ? '#d9ac32' : '#9eb9ae') ?? [],
      borderRadius: 4,
      maxBarThickness: 21,
    }],
  }), [hourly]);

  const zoneChartData = useMemo(() => {
    const topZones = zones?.slice(0, 7) ?? [];
    return {
      labels: topZones.map(item => item.pickupZone),
      datasets: [{
        data: topZones.map(item => item.trips),
        backgroundColor: topZones.map((_, index) => index === 0 ? '#275f58' : '#b9c9bd'),
        borderRadius: 4,
        maxBarThickness: 20,
      }],
    };
  }, [zones]);

  const exportCsv = () => {
    if (initialized) window.location.assign(getExportTripsCsvUrl(params));
  };
  const resetFilters = () => setSelected({ startDate: filters?.minDate ?? '', endDate: filters?.maxDate ?? '', pickupZone: '' });
  const hasSelection = selected.startDate !== (filters?.minDate ?? '') ||
    selected.endDate !== (filters?.maxDate ?? '') ||
    !!selected.pickupZone;
  const metricLoading = !initialized || summaryQuery.isLoading;
  const apiError = [summaryQuery.error, hourlyQuery.error, zoneQuery.error, revenueQuery.error, tripsQuery.error].find(Boolean);

  return <div className="dashboard-shell">
    <aside className="side-rail">
      <div className="flex items-center gap-3 px-2">
        <div className="brand-mark"><CarFront size={20} strokeWidth={2.2} /></div>
        <div className="brand-label">
          <p className="font-display text-[15px] font-extrabold leading-tight tracking-[-.04em]">Taxi Atlas</p>
          <p className="mt-0.5 font-mono-ui text-[9px] uppercase tracking-[.12em] text-white/45">Student field lab</p>
        </div>
      </div>
      <div className="rail-caption mb-2 mt-11 px-3 font-mono-ui text-[9px] uppercase tracking-[.16em] text-white/35">Workspace</div>
      <nav className="flex flex-col gap-1">
        <a className="nav-item active" aria-current="page" href="#dashboard-title"><BarChart3 size={17} /><span className="nav-label">Trip analytics</span></a>
        <a className="nav-item" href="#pickup-geography"><MapPin size={17} /><span className="nav-label">Pickup geography</span></a>
        <a className="nav-item" href="#dataset-guide"><Database size={17} /><span className="nav-label">Dataset guide</span></a>
      </nav>
      <div className="mt-auto rounded-xl border border-white/10 bg-white/[.04] p-3.5">
        <div className="flex items-center gap-2 text-xs font-semibold"><CircleHelp size={14} className="text-[hsl(var(--sidebar-primary))]" /> Study note</div>
        <p className="rail-footer mt-2 text-[11px] leading-relaxed text-white/55">Use filters to compare demand patterns across time and pickup areas.</p>
      </div>
      <div className="brand-label mt-5 px-2 font-mono-ui text-[9px] tracking-wide text-white/35">MULTI-DATASET ANALYSIS</div>
    </aside>

    <main className="main-stage">
      <header className="topbar">
        <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="font-medium text-foreground">Explore</span><span>/</span><span>Trip analytics</span></div>
        <div className="flex items-center gap-2.5">
          <span className={`h-2 w-2 rounded-full ${healthQuery.isSuccess ? 'bg-emerald-600' : healthQuery.isError ? 'bg-red-500' : 'bg-amber-500'}`} />
          <span className="font-mono-ui text-[10px] uppercase tracking-[.08em] text-muted-foreground">{healthQuery.isSuccess ? 'Data service online' : healthQuery.isError ? 'Service unavailable' : 'Connecting to data'}</span>
        </div>
      </header>

      <div className="content-wrap">
        <section className="rise-in flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <div className="mb-2 flex items-center gap-2 font-mono-ui text-[10px] uppercase tracking-[.15em] text-primary">
              <span className="h-[1px] w-5 bg-primary" /> Mobility research / 01
            </div>
          <h1 id="dashboard-title" className="font-display text-[32px] font-extrabold leading-tight tracking-[-.055em] sm:text-[39px]" data-testid="text-dashboard-title">Taxi trip patterns</h1>
            <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-muted-foreground">A hands-on look at where rides begin, when the city moves, and how trip revenue shifts.</p>
          </div>
          <button className="action-button primary self-start md:self-auto" onClick={exportCsv} disabled={!initialized} data-testid="button-export-csv">
            <ArrowDownToLine size={15} /> Download CSV
          </button>
        </section>

        {filterQuery.isError && <section className="panel mt-7 flex flex-wrap items-center justify-between gap-4 border-red-300/70 p-4" role="alert">
          <div><p className="text-sm font-semibold">Filter options could not be loaded</p><p className="mt-1 text-xs text-muted-foreground">{errorMessage(filterQuery.error)}</p></div>
          <button className="action-button outline" onClick={() => filterQuery.refetch()} data-testid="button-retry-filters"><RotateCcw size={13} /> Retry</button>
        </section>}

        <section className="panel rise-in mt-7 p-4 sm:p-5" style={{ animationDelay: '.04s' }}>
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2"><span className="font-mono-ui text-[10px] font-medium uppercase tracking-[.13em]">Slice the dataset</span><ChevronDown size={13} className="text-muted-foreground" /></div>
            {hasSelection && <button className="flex items-center gap-1.5 text-[11px] font-semibold text-primary hover:underline" onClick={resetFilters} data-testid="button-reset-filters"><RotateCcw size={12} /> Reset</button>}
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1.2fr_1.35fr_auto]">
            <label className="flex flex-col gap-1.5 text-[10px] font-semibold uppercase tracking-[.08em] text-muted-foreground">
              <span className="flex items-center gap-1.5"><CalendarDays size={12} /> From date</span>
              <input className="control-input" type="date" value={selected.startDate} min={filters?.minDate ?? undefined} max={selected.endDate || filters?.maxDate || undefined} onChange={event => setSelected(value => ({ ...value, startDate: event.target.value }))} disabled={!initialized} data-testid="input-start-date" />
            </label>
            <label className="flex flex-col gap-1.5 text-[10px] font-semibold uppercase tracking-[.08em] text-muted-foreground">
              <span className="flex items-center gap-1.5"><CalendarDays size={12} /> Through date</span>
              <input className="control-input" type="date" value={selected.endDate} min={selected.startDate || filters?.minDate || undefined} max={filters?.maxDate ?? undefined} onChange={event => setSelected(value => ({ ...value, endDate: event.target.value }))} disabled={!initialized} data-testid="input-end-date" />
            </label>
            <label className="flex flex-col gap-1.5 text-[10px] font-semibold uppercase tracking-[.08em] text-muted-foreground">
              <span className="flex items-center gap-1.5"><MapPin size={12} /> {filters?.zoneLabel ?? 'Pickup zone'}</span>
              <select className="control-input" value={selected.pickupZone} onChange={event => setSelected(value => ({ ...value, pickupZone: event.target.value }))} disabled={!initialized || !filters?.zones.length} data-testid="select-pickup-zone">
                <option value="">{filters?.zoneLabel === 'City' ? 'All cities' : 'All pickup zones'}</option>
                {filters?.zones.map(zone => <option value={zone} key={zone}>{zone}</option>)}
              </select>
            </label>
            <label className="flex flex-col gap-1.5 text-[10px] font-semibold uppercase tracking-[.08em] text-muted-foreground">
              <span className="flex items-center gap-1.5"><Database size={12} /> Dataset</span>
              <select
                className="control-input"
                value={selectedDataset}
                onChange={event => {
                  setReadyDataset('');
                  setSelectedDataset(event.target.value as TripFilters['datasetId']);
                }}
                data-testid="select-dataset"
              >
                {filters?.datasets.map(dataset => <option value={dataset.id} key={dataset.id}>{dataset.label}</option>)}
              </select>
            </label>
            <div className="flex items-end">
              <div className="flex h-[38px] w-full items-center gap-2 rounded-lg bg-secondary/80 px-3 text-[10px] text-muted-foreground sm:w-auto">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                {summaryQuery.isFetching ? 'Refreshing view…' : 'Filters update live'}
              </div>
            </div>
          </div>
        </section>

        <section className="mt-5">
          {filters && <div id="dataset-guide" className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[hsl(var(--accent)/.55)] bg-[hsl(var(--accent)/.18)] px-4 py-3" data-testid="status-dataset">
            <div className="flex items-center gap-2.5">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-[hsl(var(--accent)/.55)] text-foreground"><Database size={14} /></span>
              <div><p className="text-[12px] font-semibold">{filters.synthetic ? 'Synthetic teaching data' : 'User-provided CSV data'}</p><p className="mt-0.5 text-[11px] text-muted-foreground">{filters.description}</p></div>
            </div>
            <span className="font-mono-ui text-[9px] uppercase tracking-[.1em] text-muted-foreground">
              {number(filters.cleanedRecords)} analyzed / {number(filters.sourceRecords)} source rows
            </span>
          </div>}
        </section>

        {apiError && <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-red-300/70 bg-red-50/70 px-4 py-3 text-red-900" role="alert">
          <div><p className="text-xs font-semibold">Some results failed to load</p><p className="mt-1 text-[11px]">{errorMessage(apiError)}</p></div>
          <button className="action-button outline border-red-300" onClick={() => { summaryQuery.refetch(); hourlyQuery.refetch(); zoneQuery.refetch(); revenueQuery.refetch(); tripsQuery.refetch(); }} data-testid="button-retry-all"><RotateCcw size={13} /> Retry results</button>
        </div>}

        <section className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Metric label="Total trips" value={summary ? number(summary.totalTrips) : '—'} detail={filters?.synthetic ? 'Valid trips in selection' : 'Completed trips in selection'} icon={CarFront} loading={metricLoading} />
          <Metric label="Trip revenue" value={summary ? currency(summary.totalRevenue) : '—'} detail="Total trip charges in selection" icon={Wallet} loading={metricLoading} />
          <Metric label="Average fare" value={summary ? currency(summary.averageFare) : '—'} detail="Per trip, before tip" icon={ArrowUpRight} loading={metricLoading} />
          <Metric label="Average distance" value={summary ? `${summary.averageDistance.toFixed(1)} ${filters?.distanceUnit ?? 'mi'}` : '—'} detail={`Average distance per trip${filters?.distanceUnit ? ` (${filters.distanceUnit})` : ''}`} icon={Activity} loading={metricLoading} />
        </section>

        <section className="mt-5 grid grid-cols-1 gap-4 xl:grid-cols-[1.55fr_1fr]">
          <article className="panel p-4 sm:p-5">
            <div className="mb-5 flex items-start justify-between gap-3">
              <div><p className="font-display text-[15px] font-bold tracking-[-.025em]">Revenue over time</p><p className="mt-1 text-[11px] text-muted-foreground">Daily trip revenue · pickup date</p></div>
              <span className="rounded-md bg-secondary px-2 py-1 font-mono-ui text-[9px] uppercase tracking-wide text-muted-foreground">USD / day</span>
            </div>
            <ChartState loading={!initialized || revenueQuery.isLoading} error={revenueQuery.error} empty={!daily?.length} onRetry={() => revenueQuery.refetch()}>
              <Line data={dailyChartData} options={{
                ...chartOptions,
                scales: {
                  ...chartOptions.scales,
                  y: { ...chartOptions.scales.y, ticks: { ...chartOptions.scales.y.ticks, callback: (tickValue: string | number) => `$${tickValue}` } },
                },
              }} />
            </ChartState>
          </article>
          <article className="panel p-4 sm:p-5">
            <div className="mb-5 flex items-start justify-between gap-3">
              <div><p className="font-display text-[15px] font-bold tracking-[-.025em]">When rides start</p><p className="mt-1 text-[11px] text-muted-foreground">Pickup hour · 24-hour local time</p></div>
              <span className="rounded-md bg-secondary px-2 py-1 font-mono-ui text-[9px] uppercase tracking-wide text-muted-foreground">trips / hour</span>
            </div>
            <ChartState loading={!initialized || hourlyQuery.isLoading} error={hourlyQuery.error} empty={!hourly?.some(point => point.trips > 0)} onRetry={() => hourlyQuery.refetch()}>
              <Bar data={hourlyChartData} options={{ ...chartOptions, scales: { ...chartOptions.scales, x: { ...chartOptions.scales.x, ticks: { ...chartOptions.scales.x.ticks, maxRotation: 0, autoSkip: true, maxTicksLimit: 12 } } } }} />
            </ChartState>
          </article>
        </section>

        <section className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-[.9fr_1.5fr]">
          <article id="pickup-geography" className="panel p-4 sm:p-5">
            <div className="mb-4 flex items-start justify-between">
              <div><p className="font-display text-[15px] font-bold tracking-[-.025em]">Trip hotspots</p><p className="mt-1 text-[11px] text-muted-foreground">Most active {filters?.zoneLabel === 'City' ? 'cities' : 'pickup zones'}</p></div>
              <MapPin size={16} className="text-primary" />
            </div>
            <ChartState loading={!initialized || zoneQuery.isLoading} error={zoneQuery.error} empty={!zones?.length} onRetry={() => zoneQuery.refetch()}>
              <Bar data={zoneChartData} options={{
                ...chartOptions,
                indexAxis: 'y' as const,
                scales: {
                  x: { ...chartOptions.scales.x, grid: { color: 'rgba(91,112,102,.11)' } },
                  y: { ...chartOptions.scales.y, grid: { display: false }, ticks: { ...chartOptions.scales.y.ticks, font: { family: 'DM Sans', size: 10 } } },
                },
              }} />
            </ChartState>
          </article>
          <article className="panel overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 pb-3 pt-4 sm:px-5 sm:pt-5">
              <div><p className="font-display text-[15px] font-bold tracking-[-.025em]">Recent trips</p><p className="mt-1 text-[11px] text-muted-foreground">{trips ? `${number(trips.total)} records match this selection` : 'Latest records in the selected slice'}</p></div>
              <span className="flex items-center gap-1.5 rounded-md bg-secondary px-2 py-1 font-mono-ui text-[9px] uppercase tracking-wide text-muted-foreground"><Clock3 size={11} /> Latest 10</span>
            </div>
            {!initialized || tripsQuery.isLoading ? <LoadingTable /> :
              tripsQuery.error ? <div className="m-4 rounded-lg bg-secondary/60 p-4 text-xs"><p className="font-semibold">Trip records unavailable</p><p className="mt-1 text-muted-foreground">{errorMessage(tripsQuery.error)}</p><button className="mt-3 flex items-center gap-1.5 font-semibold text-primary" onClick={() => tripsQuery.refetch()} data-testid="button-retry-trips"><RotateCcw size={12} /> Retry</button></div> :
                trips?.items.length ? <div className="table-scroll">
                    <table>
                    <thead>{filters?.datasetId === 'uber_50k' ?
                      <tr><th>Pickup</th><th>City</th><th>Status</th><th>Distance</th><th>Fare</th><th>Payment</th></tr> :
                      <tr><th>Pickup</th><th>Pickup zone</th><th>Drop-off zone</th><th>Distance</th><th>Fare</th><th>Total</th></tr>}
                    </thead>
                    <tbody>{trips.items.map((trip: Trip) => <tr key={trip.tripId} data-testid={`row-trip-${trip.tripId}`}>
                      <td className="whitespace-nowrap font-mono-ui text-[10px]">{timeLabel(trip.pickupDatetime)}</td>
                      <td className="max-w-[145px] truncate font-medium">{trip.pickupZone}</td>
                      {filters?.datasetId === 'uber_50k' ? <>
                        <td className="text-muted-foreground">{trip.status}</td>
                        <td className="whitespace-nowrap font-mono-ui">{trip.tripDistance.toFixed(1)} {filters.distanceUnit}</td>
                        <td className="whitespace-nowrap font-mono-ui">{currency(trip.fareAmount)}</td>
                        <td className="text-muted-foreground">{trip.paymentType}</td>
                      </> : <>
                        <td className="max-w-[145px] truncate text-muted-foreground">{trip.dropoffZone}</td>
                        <td className="whitespace-nowrap font-mono-ui">{trip.tripDistance.toFixed(1)} {filters?.distanceUnit ?? 'mi'}</td>
                        <td className="whitespace-nowrap font-mono-ui">{currency(trip.fareAmount)}</td>
                        <td className="whitespace-nowrap font-mono-ui font-medium">{currency(trip.totalAmount)}</td>
                      </>}
                    </tr>)}</tbody>
                  </table>
                </div> : <div className="flex min-h-[190px] flex-col items-center justify-center px-5 text-center">
                  <div className="grid h-10 w-10 place-items-center rounded-full bg-secondary text-muted-foreground"><CarFront size={19} /></div>
                  <p className="mt-3 text-sm font-semibold">No trips to show</p><p className="mt-1 text-xs text-muted-foreground">Adjust your filters to find matching rides.</p>
                </div>}
          </article>
        </section>

        <footer className="mt-6 flex flex-col gap-2 border-t border-border pt-4 text-[10px] text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p className="flex items-center gap-1.5"><Check size={12} className="text-primary" /> For learning and exploration only · Not for operational decisions</p>
          <p className="font-mono-ui uppercase tracking-[.08em]">Taxi Atlas / Mobility field lab</p>
        </footer>
      </div>
    </main>
  </div>;
}
