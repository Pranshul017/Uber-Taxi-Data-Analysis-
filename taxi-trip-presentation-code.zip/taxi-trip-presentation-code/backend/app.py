"""Flask REST API for a user-provided taxi CSV and a synthetic teaching sample.

All dataset cleaning and aggregation is performed with PySpark. The uploaded file's
authenticity and licensing are not independently verified.
"""

from __future__ import annotations

import csv
import io
import os
import threading
from datetime import date
from pathlib import Path
from typing import Any

from flask import Flask, Response, jsonify, request
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    DoubleType,
    IntegerType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

app = Flask(__name__)
DATA_DIR = Path(__file__).resolve().parents[1] / "data"
DEFAULT_DATASET = "uber_50k"

TRIP_SCHEMA = StructType(
    [
        StructField("tripId", StringType(), True),
        StructField("pickupDatetime", TimestampType(), True),
        StructField("dropoffDatetime", TimestampType(), True),
        StructField("pickupZone", StringType(), True),
        StructField("dropoffZone", StringType(), True),
        StructField("passengerCount", IntegerType(), True),
        StructField("tripDistance", DoubleType(), True),
        StructField("fareAmount", DoubleType(), True),
        StructField("tipAmount", DoubleType(), True),
        StructField("totalAmount", DoubleType(), True),
        StructField("paymentType", StringType(), True),
    ]
)

UPLOADED_SCHEMA = StructType(
    [
        StructField("trip_id", StringType(), True),
        StructField("driver_id", StringType(), True),
        StructField("rider_id", StringType(), True),
        StructField("city", StringType(), True),
        StructField("pickup_lat", DoubleType(), True),
        StructField("pickup_lng", DoubleType(), True),
        StructField("drop_lat", DoubleType(), True),
        StructField("drop_lng", DoubleType(), True),
        StructField("distance_km", DoubleType(), True),
        StructField("fare_amount", DoubleType(), True),
        StructField("status", StringType(), True),
        StructField("payment_method", StringType(), True),
        StructField("pickup_time", TimestampType(), True),
        StructField("drop_time", TimestampType(), True),
    ]
)

UPLOADED_EXPORT_COLUMNS = [
    "trip_id",
    "driver_id",
    "rider_id",
    "city",
    "pickup_lat",
    "pickup_lng",
    "drop_lat",
    "drop_lng",
    "distance_km",
    "fare_amount",
    "status",
    "payment_method",
    "pickup_time",
    "drop_time",
]

DATASETS: dict[str, dict[str, Any]] = {
    "uber_50k": {
        "label": "Uploaded 50k CSV",
        "path": DATA_DIR / "uber_trips_50k.csv",
        "schema": UPLOADED_SCHEMA,
        "timestampFormat": "yyyy-MM-dd HH:mm:ss[.SSSSSSSSS]",
        "synthetic": False,
        "distanceUnit": "km",
        "zoneLabel": "City",
        "description": (
            "User-provided CSV with 50,000 source rows. Analytics include completed "
            "rides only; non-completed and invalid records are excluded. The source's "
            "authenticity and licensing have not been independently verified."
        ),
    },
    "synthetic": {
        "label": "Synthetic teaching sample",
        "path": DATA_DIR / "synthetic_taxi_trips.csv",
        "schema": TRIP_SCHEMA,
        "timestampFormat": "yyyy-MM-dd'T'HH:mm:ss",
        "synthetic": True,
        "distanceUnit": "mi",
        "zoneLabel": "Pickup zone",
        "description": (
            "Hand-authored synthetic classroom data with intentionally invalid rows "
            "for demonstrating Spark data cleaning."
        ),
    },
}

_spark: SparkSession | None = None
_cleaned_trips: dict[str, DataFrame] = {}
_source_counts: dict[str, int] = {}
_cleaned_counts: dict[str, int] = {}
_dataset_lock = threading.Lock()


def requested_dataset_id() -> str:
    dataset_id = request.args.get("dataset", DEFAULT_DATASET)
    if dataset_id not in DATASETS:
        valid = ", ".join(DATASETS)
        raise ValueError(f"dataset must be one of: {valid}")
    return dataset_id


def get_cleaned_trips(dataset_id: str) -> DataFrame:
    """Read, normalize, clean, and cache one dataset using PySpark."""
    global _spark
    if dataset_id in _cleaned_trips:
        return _cleaned_trips[dataset_id]

    with _dataset_lock:
        if dataset_id in _cleaned_trips:
            return _cleaned_trips[dataset_id]
        spec = DATASETS[dataset_id]
        data_path: Path = spec["path"]
        if not data_path.is_file():
            raise FileNotFoundError(f"Dataset file not found: {data_path}")

        if _spark is None:
            _spark = (
                SparkSession.builder.master("local[*]")
                .appName("TaxiTripDataAnalysis")
                .config("spark.ui.enabled", "false")
                .config("spark.sql.session.timeZone", "UTC")
                .config(
                    "spark.sql.shuffle.partitions",
                    os.environ.get("SPARK_SQL_SHUFFLE_PARTITIONS", "8"),
                )
                .getOrCreate()
            )
            _spark.sparkContext.setLogLevel("ERROR")
        raw = (
            _spark.read.option("header", True)
            .option("mode", "PERMISSIVE")
            .option("timestampFormat", spec["timestampFormat"])
            .schema(spec["schema"])
            .csv(str(data_path))
        )

        if dataset_id == "uber_50k":
            trips = (
                raw.withColumn("tripId", F.col("trip_id").cast(StringType()))
                .withColumn("pickupDatetime", F.col("pickup_time"))
                .withColumn("dropoffDatetime", F.col("drop_time"))
                .withColumn("pickupZone", F.trim(F.col("city")))
                .withColumn("dropoffZone", F.lit(None).cast(StringType()))
                .withColumn("passengerCount", F.lit(None).cast(IntegerType()))
                .withColumn("tripDistance", F.col("distance_km").cast(DoubleType()))
                .withColumn("fareAmount", F.col("fare_amount").cast(DoubleType()))
                .withColumn("tipAmount", F.lit(0.0))
                .withColumn("totalAmount", F.col("fare_amount").cast(DoubleType()))
                .withColumn("paymentType", F.col("payment_method"))
            )
        else:
            trips = raw.withColumn("status", F.lit("Completed"))

        required_text = (
            F.col("tripId").isNotNull()
            & (F.length(F.trim(F.col("tripId"))) > 0)
            & F.col("pickupDatetime").isNotNull()
            & F.col("dropoffDatetime").isNotNull()
            & F.col("pickupZone").isNotNull()
            & (F.length(F.trim(F.col("pickupZone"))) > 0)
            & F.col("status").isNotNull()
        )
        valid_values = (
            (F.col("passengerCount").isNull() | F.col("passengerCount").between(1, 8))
            & (F.col("tripDistance") > 0)
            & (F.col("fareAmount") >= 0)
            & (F.col("tipAmount") >= 0)
            & (F.col("totalAmount") >= 0)
            & (F.col("dropoffDatetime") > F.col("pickupDatetime"))
        )

        clean = trips.filter(required_text & valid_values)
        if dataset_id == "uber_50k":
            clean = clean.filter(F.upper(F.trim(F.col("status"))) == "COMPLETED")
        clean = clean.dropDuplicates(["tripId"]).cache()

        _source_counts[dataset_id] = raw.count()
        _cleaned_counts[dataset_id] = clean.count()
        _cleaned_trips[dataset_id] = clean
        return clean


def parse_date_param(name: str) -> date | None:
    value = request.args.get(name)
    if value is None or value == "":
        return None
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be a date in YYYY-MM-DD format") from exc


def filtered_trips(dataset_id: str | None = None) -> DataFrame:
    start_date = parse_date_param("startDate")
    end_date = parse_date_param("endDate")
    if start_date and end_date and start_date > end_date:
        raise ValueError("startDate cannot be after endDate")

    dataset_id = dataset_id or requested_dataset_id()
    trips = get_cleaned_trips(dataset_id)
    if start_date:
        trips = trips.filter(F.to_date("pickupDatetime") >= F.lit(start_date))
    if end_date:
        trips = trips.filter(F.to_date("pickupDatetime") <= F.lit(end_date))

    pickup_zone = request.args.get("pickupZone")
    if pickup_zone:
        trips = trips.filter(F.col("pickupZone") == pickup_zone)
    return trips


def trip_to_json(row: Any) -> dict[str, Any]:
    return {
        "tripId": row["tripId"],
        "pickupDatetime": row["pickupDatetime"].isoformat(),
        "dropoffDatetime": row["dropoffDatetime"].isoformat(),
        "pickupZone": row["pickupZone"],
        "dropoffZone": row["dropoffZone"],
        "passengerCount": int(row["passengerCount"]) if row["passengerCount"] is not None else None,
        "tripDistance": float(row["tripDistance"]),
        "fareAmount": float(row["fareAmount"]),
        "tipAmount": float(row["tipAmount"]),
        "totalAmount": float(row["totalAmount"]),
        "paymentType": row["paymentType"] or "Unknown",
        "status": row["status"],
    }


def report_api_error(exc: Exception, status_code: int = 500):
    if status_code == 400:
        app.logger.info("Rejected invalid taxi analytics query: %s", exc)
    else:
        app.logger.exception("Taxi analytics request failed")
    return jsonify({"error": str(exc) if status_code == 400 else "Analytics service failed. Check the backend logs."}), status_code


@app.get("/api/healthz")
def health_check():
    # The endpoint initializes Spark, so a successful response means PySpark and
    # its Java runtime started successfully rather than reporting a false status.
    get_cleaned_trips(DEFAULT_DATASET)
    return jsonify(
        {
            "status": "ok",
            "engine": "PySpark local[*]",
            "datasetId": DEFAULT_DATASET,
            "sourceRecords": _source_counts[DEFAULT_DATASET],
            "cleanedRecords": _cleaned_counts[DEFAULT_DATASET],
        }
    )


@app.get("/api/trips/summary")
def trips_summary():
    try:
        stats = filtered_trips().agg(
            F.count("*").alias("totalTrips"),
            F.sum("totalAmount").alias("totalRevenue"),
            F.avg("fareAmount").alias("averageFare"),
            F.avg("tripDistance").alias("averageDistance"),
        ).first()
        return jsonify(
            {
                "totalTrips": int(stats["totalTrips"] or 0),
                "totalRevenue": round(float(stats["totalRevenue"] or 0), 2),
                "averageFare": round(float(stats["averageFare"] or 0), 2),
                "averageDistance": round(float(stats["averageDistance"] or 0), 2),
            }
        )
    except ValueError as exc:
        return report_api_error(exc, 400)
    except Exception as exc:
        return report_api_error(exc)


@app.get("/api/trips")
def list_trips():
    try:
        limit = int(request.args.get("limit", "10"))
        offset = int(request.args.get("offset", "0"))
        if not 1 <= limit <= 500:
            raise ValueError("limit must be between 1 and 500")
        if offset < 0:
            raise ValueError("offset cannot be negative")

        trips = filtered_trips()
        total = trips.count()
        rows = (
            trips.orderBy(F.col("pickupDatetime").desc(), F.col("tripId"))
            .limit(offset + limit)
            .collect()[offset:]
        )
        return jsonify({"items": [trip_to_json(row) for row in rows], "total": total})
    except (ValueError, TypeError) as exc:
        return report_api_error(exc, 400)
    except Exception as exc:
        return report_api_error(exc)


@app.get("/api/analytics/by-hour")
def trips_by_hour():
    try:
        rows = (
            filtered_trips()
            .groupBy(F.hour("pickupDatetime").alias("hour"))
            .agg(F.count("*").alias("trips"))
            .collect()
        )
        counts = {int(row["hour"]): int(row["trips"]) for row in rows}
        return jsonify([{"hour": hour, "trips": counts.get(hour, 0)} for hour in range(24)])
    except ValueError as exc:
        return report_api_error(exc, 400)
    except Exception as exc:
        return report_api_error(exc)


@app.get("/api/analytics/pickup-zones")
def trips_by_pickup_zone():
    try:
        rows = (
            filtered_trips()
            .groupBy("pickupZone")
            .agg(F.count("*").alias("trips"))
            .orderBy(F.col("trips").desc(), F.col("pickupZone").asc())
            .limit(8)
            .collect()
        )
        return jsonify(
            [{"pickupZone": row["pickupZone"], "trips": int(row["trips"])} for row in rows]
        )
    except ValueError as exc:
        return report_api_error(exc, 400)
    except Exception as exc:
        return report_api_error(exc)


@app.get("/api/analytics/daily-revenue")
def daily_revenue():
    try:
        rows = (
            filtered_trips()
            .groupBy(F.to_date("pickupDatetime").alias("date"))
            .agg(
                F.sum("totalAmount").alias("revenue"),
                F.count("*").alias("trips"),
            )
            .orderBy("date")
            .collect()
        )
        return jsonify(
            [
                {
                    "date": row["date"].isoformat(),
                    "revenue": round(float(row["revenue"] or 0), 2),
                    "trips": int(row["trips"]),
                }
                for row in rows
            ]
        )
    except ValueError as exc:
        return report_api_error(exc, 400)
    except Exception as exc:
        return report_api_error(exc)


@app.get("/api/filters")
def trip_filters():
    try:
        dataset_id = requested_dataset_id()
        spec = DATASETS[dataset_id]
        trips = get_cleaned_trips(dataset_id)
        dates = trips.agg(
            F.min(F.to_date("pickupDatetime")).alias("minDate"),
            F.max(F.to_date("pickupDatetime")).alias("maxDate"),
        ).first()
        zones = [
            row["pickupZone"]
            for row in trips.select("pickupZone").distinct().orderBy("pickupZone").collect()
        ]
        return jsonify(
            {
                "zones": zones,
                "minDate": dates["minDate"].isoformat() if dates["minDate"] else None,
                "maxDate": dates["maxDate"].isoformat() if dates["maxDate"] else None,
                "datasetId": dataset_id,
                "dataset": spec["label"],
                "datasets": [
                    {
                        "id": option_id,
                        "label": option["label"],
                        "synthetic": option["synthetic"],
                    }
                    for option_id, option in DATASETS.items()
                ],
                "synthetic": spec["synthetic"],
                "distanceUnit": spec["distanceUnit"],
                "zoneLabel": spec["zoneLabel"],
                "description": spec["description"],
                "sourceRecords": _source_counts[dataset_id],
                "cleanedRecords": _cleaned_counts[dataset_id],
                "excludedRecords": _source_counts[dataset_id] - _cleaned_counts[dataset_id],
            }
        )
    except ValueError as exc:
        return report_api_error(exc, 400)
    except Exception as exc:
        return report_api_error(exc)


@app.get("/api/trips/export")
def export_trips_csv():
    try:
        dataset_id = requested_dataset_id()
        trips = filtered_trips(dataset_id).orderBy(
            F.col("pickupDatetime").desc(), F.col("tripId")
        )
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        export_columns = (
            UPLOADED_EXPORT_COLUMNS
            if dataset_id == "uber_50k"
            else TRIP_SCHEMA.fieldNames()
        )
        writer.writerow(export_columns)
        for row in trips.toLocalIterator():
            values = row.asDict()
            if dataset_id == "uber_50k":
                row_values = [values[column] for column in export_columns]
            else:
                row_values = [
                    values["tripId"],
                    values["pickupDatetime"].isoformat(),
                    values["dropoffDatetime"].isoformat(),
                    values["pickupZone"],
                    values["dropoffZone"],
                    values["passengerCount"],
                    values["tripDistance"],
                    values["fareAmount"],
                    values["tipAmount"],
                    values["totalAmount"],
                    values["paymentType"],
                ]
            writer.writerow(
                [value.isoformat() if hasattr(value, "isoformat") else value for value in row_values]
            )
        filename = "uber-trips-filtered.csv" if dataset_id == "uber_50k" else "synthetic-trips-filtered.csv"
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except ValueError as exc:
        return report_api_error(exc, 400)
    except Exception as exc:
        return report_api_error(exc)


@app.errorhandler(404)
def not_found(_error):
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(500)
def internal_error(_error):
    return jsonify({"error": "Analytics service failed. Check the backend logs."}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
